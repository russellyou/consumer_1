package com.common;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

/**
 * this name strategy will use camel case with first letter Upper case
 */
@JsonNaming(PropertyNamingStrategy.UpperCamelCaseStrategy.class)
public class Price {


    private String spotBidCustomerRate;
    private String spotAskCustomerRate;
    private String l1_AllInBidRate;
    private String l1_AllInAskRate;

    private String spotBidRate;
    private String spotAskRate;


    public String getSpotBidRate() {
        return spotBidRate;
    }

    public void setSpotBidRate(String spotBidRate) {
        this.spotBidRate = spotBidRate;
    }

    public String getSpotAskRate() {
        return spotAskRate;
    }

    public void setSpotAskRate(String spotAskRate) {
        this.spotAskRate = spotAskRate;
    }

    public String getSpotBidCustomerRate() {
        return spotBidCustomerRate;
    }

    public void setSpotBidCustomerRate(String spotBidCustomerRate) {
        this.spotBidCustomerRate = spotBidCustomerRate;
    }

    public String getSpotAskCustomerRate() {
        return spotAskCustomerRate;
    }

    public void setSpotAskCustomerRate(String spotAskCustomerRate) {
        this.spotAskCustomerRate = spotAskCustomerRate;
    }

    public String getL1_AllInBidRate() {
        return l1_AllInBidRate;
    }

    public void setL1_AllInBidRate(String l1_AllInBidRate) {
        this.l1_AllInBidRate = l1_AllInBidRate;
    }

    public String getL1_AllInAskRate() {
        return l1_AllInAskRate;
    }

    public void setL1_AllInAskRate(String l1_AllInAskRate) {
        this.l1_AllInAskRate = l1_AllInAskRate;
    }
}
