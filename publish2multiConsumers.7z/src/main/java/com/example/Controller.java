/*
 * Copyright 2018-2019 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example;

import com.common.Price;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.common.Foo1;

import java.awt.print.PrinterException;
import java.util.Random;

/**
 * @author Gary Russell
 * @since 2.2.1
 */
@RestController
public class Controller {

	@Autowired
	private KafkaTemplate<Object, Object> template;
	// 256 byte
	private String dummy = "-0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef";

	@Value("${price.count}")
	private int priceCount ;

	@PostMapping(path = "/send/{topic}/{what}")
	public void sendFoo(@PathVariable String topic, @PathVariable String what) throws InterruptedException {
		for (int i = 0; i < priceCount; i++) {
			this.template.send(topic, i+dummy);
			Thread.sleep(500);
		}
	}


	@PostMapping(path = "/send/price")
	public void sendFoo() throws InterruptedException {
		Random random = new Random();
		for (int i = 0; i < priceCount; i++) {
			Price price = new Price();
			price.setSpotBidCustomerRate(String.valueOf(random.nextDouble()));
			price.setSpotAskCustomerRate(String.valueOf(random.nextDouble()));
			price.setL1_AllInBidRate(String.valueOf(random.nextDouble()));
			price.setL1_AllInAskRate(String.valueOf(random.nextDouble()));
			price.setSpotAskRate(String.valueOf(random.nextDouble()));
			price.setSpotBidRate(String.valueOf(random.nextDouble()));
			this.template.send("topic2", price);
			Thread.sleep(2000);
		}
	}

}
